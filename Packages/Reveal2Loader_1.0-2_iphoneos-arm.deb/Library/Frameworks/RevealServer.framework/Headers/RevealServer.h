//
//  RevealServer.h
//  RevealServer
//
//  Created by Tony Arnold on 25/11/2015.
//  Copyright © 2015 Itty Bitty Apps, Pty Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RevealServer.
FOUNDATION_EXPORT double RevealServerVersionNumber;

//! Project version string for RevealServer.
FOUNDATION_EXPORT const unsigned char RevealServerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RevealServer/PublicHeader.h>


